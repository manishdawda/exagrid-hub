
# ExaGrid Competitive & Comparative Hub — Starter

A minimal, SEO-ready static site optimized for GitHub Pages. Replace placeholders (`YOUR_DOMAIN`, `YOUR_BRAND`, etc.) and add content.

## Files
- `index.html` — homepage with SEO meta, OG/Twitter tags, Organization JSON-LD
- `assets/styles.css` — basic styling
- `robots.txt` — allows crawling and points to sitemap
- `sitemap.xml` — basic XML sitemap

## Quick Deploy (GitHub Pages)
1. Create a public repo on GitHub.
2. Upload these files (keep the same structure).
3. In **Settings → Pages**: Source = `Deploy from a branch`, Branch = `main`, Folder = `/root`.
4. Wait for the build, then visit `https://USERNAME.github.io/REPO/`.
5. Add a custom domain in **Settings → Pages** and set DNS (CNAME to `USERNAME.github.io`).

## Customization
- Update meta tags and the JSON-LD block in `index.html`.
- Replace `assets/logo.png` and `assets/og-image-1200x630.jpg` with your brand assets.
- Expand sections (`comparisons`, `features`, `resources`) with sourced, factual content.
